package Test.TestMav;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import Pages.AppChoicePage;
import Pages.LoginPage;
import Resources.Base;

public class VerifyLogin extends Base {
	


@Test
public void login() throws IOException, InterruptedException
{
	driver=InitializeDriver();
	launchurl();
	
	LoginPage lp= new LoginPage(driver);
 	lp.userName().sendKeys(LoginPage.usernamevalue);
 	lp.password().sendKeys(LoginPage.passwordvalue);
 	lp.signIn().click();
 	Thread.sleep(3000);
 	System.out.println(lp.AfterLoginTitle());
 	
 	if(lp.AfterLoginTitle().equalsIgnoreCase("Gallagher Bassett - AppChoice"))
{
 		System.out.println("Logged in successfully landed in AppChoice Page");
 		
 		
}
 	else if(lp.AfterLoginTitle().equalsIgnoreCase("Gallagher Bassett - Logon"))
 	{
 		System.out.println("Login not successfull - check the credentials");
 	}
 	else
 		System.out.println("Logged in successfully landed in Home Page");
}
@Test public void appchoice() throws IOException, InterruptedException
{
	VerifyLogin vl = new VerifyLogin();
	vl.login();
	AppChoicePage acp = new AppChoicePage(driver);
		acp.risxfacsclick();
}
@AfterTest
public void print()
{
	System.out.println("Going to next case");
	driver.close();;
}
}
