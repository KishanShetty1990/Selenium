package Pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AppChoicePage {
	public WebDriver driver;
	public static String luminous,risxfacs,loggedin,changepassword,logout;

	public static void initialize() throws IOException {
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream("H:\\Latest_Framework\\TestMav\\src\\main\\java\\Pages\\appchoice.prop");
		prop.load(file);
		luminous = prop.getProperty("luminous");
		risxfacs = prop.getProperty("risxfacs");
		loggedin = prop.getProperty("loggedin");
		changepassword = prop.getProperty("changepassword");
		logout = prop.getProperty("logout");
	}

	public AppChoicePage(WebDriver driver) throws IOException {
		AppChoicePage.initialize();
		this.driver = driver;
	}

	public WebElement luminous() {
		return driver.findElement(By.xpath(luminous));
	}
	public WebElement risxfacs() {
		return driver.findElement(By.xpath(risxfacs));
	}
	public void risxfacsclick()
	{
		risxfacs().click();
	}
	public WebElement loggedin() {
		return driver.findElement(By.xpath(loggedin));
	}
	public WebElement changepassword() {
		return driver.findElement(By.xpath(changepassword));
	}
	public WebElement logout() {
		return driver.findElement(By.xpath(logout));
	}
	public String AfterLoginTitle() {
		return driver.getTitle();
	}
	
}
