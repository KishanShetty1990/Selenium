package Resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Base {
	public WebDriver driver;

	public static String browser,url;

	public static void initialize() throws IOException {
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream(
				"H:\\Latest_Framework\\TestMav\\src\\main\\java\\Resources\\data.prop");
		prop.load(file);
		browser = prop.getProperty("browser");
		url = prop.getProperty("url");
	}

	public WebDriver InitializeDriver() throws IOException {
		Base.initialize();
		if (browser.equals("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "H:\\Latest_Framework\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equals("IE"))

		{
			System.setProperty("webdriver.ie.driver", "H:\\Latest_Framework\\Drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else if (browser.equals("Firefox"))

		{
			System.setProperty("webdriver.gecko.driver", "H:\\Latest_Framework\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		} else
			System.out.println("browser type should be only Chrome or IE or Firefox");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		return driver;
	}

	public void launchurl() throws IOException {
		driver.get(url);
	}

	public void clickelement(String Xpath) throws IOException {
		driver.findElement(By.xpath(Xpath)).click();
	}
}
